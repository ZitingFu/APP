<template>
  <div class="SignIn">
    <h2>登陆页面</h2>
  </div>
</template>

<script>
export default {
  name: 'SignIn',
  data () {
    return {
      msg: ''
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
